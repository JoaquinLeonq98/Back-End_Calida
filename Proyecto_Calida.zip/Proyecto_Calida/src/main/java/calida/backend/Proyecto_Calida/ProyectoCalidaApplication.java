package calida.backend.Proyecto_Calida;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ProyectoCalidaApplication {

	public static void main(String[] args) {
		SpringApplication.run(ProyectoCalidaApplication.class, args);
	}

}
