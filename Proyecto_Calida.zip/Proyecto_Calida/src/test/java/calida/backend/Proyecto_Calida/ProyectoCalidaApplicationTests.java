package calida.backend.Proyecto_Calida;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ProyectoCalidaApplicationTests {

	@Test
	void contextLoads() {
	}

}
